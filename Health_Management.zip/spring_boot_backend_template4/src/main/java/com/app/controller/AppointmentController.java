package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Appointment;
import com.app.entity.AppointmentDTO;
import com.app.service.AppointmentService;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	public AppointmentController() {
		// TODO Auto-generated constructor stub
	}

	@PostMapping
	public ResponseEntity<?> addAppointment(@RequestBody @Valid AppointmentDTO dto) {
		return appointmentService.addNewAppointment(dto);
		
	}
	
	@GetMapping("/{doctorId}")
	public ResponseEntity<?> getAppByDoctor(@PathVariable Long doctorId){
		List<Appointment> appointments=appointmentService.getAppByDoctor(doctorId);
		if (!appointments.isEmpty()) {
			return ResponseEntity.ok(appointments);
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{deleteId}")
	public ResponseEntity<?> deleteApp(@PathVariable Long deleteId){
		return appointmentService.cancelAppointment(deleteId);
		
	}
}
