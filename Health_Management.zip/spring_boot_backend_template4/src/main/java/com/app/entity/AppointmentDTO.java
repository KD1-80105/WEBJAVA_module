package com.app.entity;

import java.time.LocalDateTime;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AppointmentDTO {
	@NotNull(message = "doc id cannot be null")
	private Long docId;

	@NotNull(message = "patient id cannot be null")
	private Long patId;

	@NotNull
	@Future
	private LocalDateTime dateTime;
	@JsonProperty(access = Access.READ_ONLY)
	private String firstName;
	@JsonProperty(access = Access.READ_ONLY)
	private String lastName;
}
