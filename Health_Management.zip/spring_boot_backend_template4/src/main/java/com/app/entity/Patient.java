package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Patient extends BaseEntity {

	@Column(length = 50)
	private String firstName;
	@Column(length = 50)
	private String lastName;
	
}
