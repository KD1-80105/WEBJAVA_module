package com.app.entity;

public enum Profession {

	GYNACOLOGIST,ORTHOLOGIST,DENTIST
}
