package com.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.app.entity.Appointment;
import com.app.entity.AppointmentDTO;
import com.app.entity.Doctor;

public interface AppointmentService {

	ResponseEntity<?> addNewAppointment(AppointmentDTO dto);
	
	List<Appointment> getAppByDoctor(Long docId);

	ResponseEntity<String> cancelAppointment(Long delId);
}
