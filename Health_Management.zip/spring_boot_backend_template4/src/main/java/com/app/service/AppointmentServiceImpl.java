	package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.dao.AppointmentDao;
import com.app.dao.DoctorDao;
import com.app.dao.PatientDao;
import com.app.entity.Appointment;
import com.app.entity.AppointmentDTO;
import com.app.entity.Doctor;
import com.app.entity.Patient;

@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentDao appointmentDao;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private DoctorDao doctorDao;
	
	@Autowired
	private PatientDao patientDao;

	@Override
	public ResponseEntity<?> addNewAppointment(AppointmentDTO newApp) {

		Doctor doctor = doctorDao.findById(newApp.getDocId()).orElseThrow();
		Patient patient=patientDao.findById(newApp.getPatId()).orElseThrow();
		
		Appointment appointment = mapper.map(newApp, Appointment.class);
		appointment.setDoctor(doctor);
		appointment.setPatient(patient);
		Appointment save1 = appointmentDao.save(appointment);
		AppointmentDTO map1 = mapper.map(save1, AppointmentDTO.class);
		return ResponseEntity.status(HttpStatus.CREATED).body(map1);
	}

	@Override
	public List<Appointment> getAppByDoctor(Long docId) {
		Doctor doctor = doctorDao.findById(docId).orElseThrow();
		List<Appointment> list=appointmentDao.findByDoctor(doctor);
		return list;
		
	}

	@Override
	public ResponseEntity<String> cancelAppointment(Long delId) {
		if (appointmentDao.existsById(delId)) {
			appointmentDao.deleteById(delId);
			return ResponseEntity.ok("Appointment deleted successfully!!!");
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Appointment cannot be  Deleted!!!");
	}

}
