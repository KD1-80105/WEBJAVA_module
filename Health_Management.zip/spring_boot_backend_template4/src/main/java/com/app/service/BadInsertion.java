package com.app.service;

public class BadInsertion extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1009138417119492936L;
	String msg;

	public BadInsertion(String msg) {
		super();
		this.msg = msg;
	}

	public BadInsertion() {
		// TODO Auto-generated constructor stub
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "BadInsertion [msg=" + msg + "]";
	}

}
