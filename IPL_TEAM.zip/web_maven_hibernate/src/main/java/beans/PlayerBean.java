package beans;

import java.time.LocalDate;
import java.time.Period;

import com.app.dao.PlayerDao;
import com.app.dao.PlayerDaoImpl;
import com.app.dao.TeamDao;
import com.app.dao.TeamDaoImpl;

import pojos.Player;
import pojos.Team;

public class PlayerBean {
	private Integer myTeam;
	private String fn;
	private String ln;
	private String dob;
	private double avg;
	private int wickets;
	private TeamDao teamDao;
	private PlayerDao playerDao;

	public PlayerBean() {
		teamDao = new TeamDaoImpl();
		playerDao = new PlayerDaoImpl();
		System.out.println("player bean created");
	}

	public Integer getMyTeam() {
		return myTeam;
	}

	public void setMyTeam(Integer myTeam) {
		this.myTeam = myTeam;
	}

	public String getFn() {
		return fn;
	}

	public void setFn(String fn) {
		this.fn = fn;
	}

	public String getLn() {
		return ln;
	}

	public void setLn(String ln) {
		this.ln = ln;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	public int getWickets() {
		return wickets;
	}

	public void setWickets(int wickets) {
		this.wickets = wickets;
	}

	public TeamDao getTeamDao() {
		return teamDao;
	}

	public void setTeamDao(TeamDao teamDao) {
		this.teamDao = teamDao;
	}

	public PlayerDao getPlayerDao() {
		return playerDao;
	}

	public void setPlayerDao(PlayerDao playerDao) {
		this.playerDao = playerDao;
	}

	public String validationAndAddPlayer() {
		String msg = "rejected";
		Team choosenTeam = teamDao.getTeamDetailById(myTeam);
		System.out.println(dob);
		LocalDate ldate = LocalDate.parse(dob);
		int age = Period.between(ldate, LocalDate.now()).getYears();
		System.out.println(avg);
		System.out.println(choosenTeam.getBattingAvg());
		if (avg > choosenTeam.getBattingAvg()) {
			if (age < choosenTeam.getMaxAge()) {
				if (wickets > choosenTeam.getWicketsTaken()) {
					Player player = new Player(fn, ln, ldate, avg, wickets);
					playerDao.addNewPlayer(myTeam, player);
					msg = "Player Added succesfully";
				}
			}
		}
		return msg;

	}

}
