package beans;


import java.util.List;

import com.app.dao.TeamDao;
import com.app.dao.TeamDaoImpl;

import pojos.Team;

public class TeamBean {
	private TeamDao teamDao;
	
	public TeamBean() {
		teamDao=new TeamDaoImpl();
		System.out.println("TEam bean and dao creaetd!!");
	}
	
	public List<Team> getAllTeams(){
		return teamDao.getTeamDetail();
	}
	
}
