package com.app.dao;

import pojos.Player;

public interface PlayerDao {
	String addNewPlayer(Integer teamId,Player player);

}
