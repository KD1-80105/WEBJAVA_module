package com.app.dao;

//import static utils.HibernateUtils.getFactory;


import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Player;
import pojos.Team;
import static utils.HibernateUtils.getFactory;
public class PlayerDaoImpl implements PlayerDao {

	@Override
	public String addNewPlayer(Integer teamId, Player player) {
		String msg = "not added";

		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();

		try {

			Team team=session.get(Team.class, teamId);
			team.addPlayer(player);

			tx.commit();
			msg = "Added emp details with ID= " ;
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();

			}
			throw e;

		}

		return msg;
	}

}
