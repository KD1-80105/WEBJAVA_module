package com.app.dao;

import java.util.List;

import pojos.Team;

public interface TeamDao {
	// add a new Team

	String addNewTeam(Team newTeam);

	// 1. Display team id n abbreviation of all the teams

	List<Team> getTeamDetail();

	// Display team details , of a team by it's id

	Team getTeamDetailById(Integer id);

	// 3. Display all those teams who need , player's max age < specific age n min
	// no of wickets taken > specified wickets
	// i/p : age , no of wickets

	List<Team> getSpecifiedTeam(int maxAge, int minWicket);

//		4. Update max age n batting avg requirement of a specific team by it's name (team name is unique)
//		i/p team name , new max age n batting avg
	String updateTeam(String name, int newMaxAge, double battingAvg);

	String deleteTeam(Integer id);
}
