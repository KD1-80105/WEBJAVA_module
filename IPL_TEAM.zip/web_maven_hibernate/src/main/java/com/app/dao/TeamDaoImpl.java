package com.app.dao;

import static utils.HibernateUtils.getFactory;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Team;

public class TeamDaoImpl implements TeamDao {

	@Override
	public String addNewTeam(Team newTeam) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Team> getTeamDetail() {
		List<Team> team = null;
		// jpql query to select id and abbrevation using constructor expressin
		String jpql = "select new  pojos.Team(id,abbreviation) from Team t";

		// get current session from faction
		Session session = getFactory().getCurrentSession();

		// begin Transaction
		Transaction tx = session.beginTransaction();

		try {
			// execute jquery and result will be result
			team = session.createQuery(jpql, Team.class).getResultList();
			// L1 cache

			tx.commit();// session.flush()->dirty check and session.close()
		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();

			}
			throw e;

		}

		return team;// detached mode
	}

	@Override
	public Team getTeamDetailById(Integer id) {
		Team team = null;
		Session session = getFactory().getCurrentSession();

		Transaction tx = session.beginTransaction();
		try {
			team = session.get(Team.class, id);
			tx.commit();
		} catch (RuntimeException exception) {
			if (tx != null) {
				tx.rollback();
			}
			throw exception;
		}
		return team;
	}

	@Override
	public List<Team> getSpecifiedTeam(int maxAge, int minWicket) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateTeam(String name, int newMaxAge, double battingAvg) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteTeam(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
