package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.CategoryDTO;
import com.app.service.CategoryService;

@RestController
@RequestMapping("/categories")
//@CrossOrigin("http://localhost:3000/categories")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	public CategoryController() {
		// TODO Auto-generated constructor stub
	}

	@PostMapping
	public CategoryDTO addNewCategory(@RequestBody CategoryDTO dto) {
		return categoryService.addNewCategory(dto);
	}
}
