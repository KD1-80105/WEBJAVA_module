package com.app.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AddProdDTO;
import com.app.dto.ProductDTO;
import com.app.dto.UpdateDTO;
import com.app.service.ProductService;

@RestController
@RequestMapping("/products")
//@CrossOrigin("http://localhost:3000/products")
public class ProductController {
	@Autowired
	private ProductService productService;

	public ProductController() {
		System.out.println("in controllers ctor");
	}

	@PostMapping()
	public ProductDTO addProducts(@RequestBody @Valid AddProdDTO dto) {
		System.out.println("in product controller ctor "+dto);
		return productService.addNewProductInCategory(dto);
	}
	
	@GetMapping("/category/{categoryId}")
	public List<ProductDTO> prodListByCategory(@PathVariable Long categoryId) {
		return productService.getByCategory(categoryId);
	}
	
	@DeleteMapping("/{prodId}")
	public String deleteById(@PathVariable Long prodId) {
		return productService.deleteById(prodId);
	}
	
	@PutMapping("/{productId}")
	public UpdateDTO updateProducts(@PathVariable Long productId,@RequestBody UpdateDTO dto) {
		return productService.updateProductDetails(productId,dto);
	}

}
