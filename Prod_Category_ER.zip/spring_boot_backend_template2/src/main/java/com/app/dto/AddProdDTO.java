package com.app.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AddProdDTO {

	@NotNull(message = "cannot be null")
	private Long catId;
	@NotBlank(message = "first name must be supplied!!!")
	private String name;
	@NotBlank
	private String description;
	@Min(value = 500,message = "price must be > 500")
	private double price;
	@Min(value = 20)
	private int stock;
	@NotNull
	@Future
	private LocalDateTime expiryDate;

}
