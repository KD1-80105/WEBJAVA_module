package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@Entity
public class Category extends BaseEntity {
	@Column(unique = true, length = 50)
	private String name;
	private String description;

}
