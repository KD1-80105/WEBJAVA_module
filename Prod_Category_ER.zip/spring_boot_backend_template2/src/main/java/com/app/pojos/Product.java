package com.app.pojos;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "productsList")
public class Product extends BaseEntity {

	@Column(unique = true, length = 20)
	private String name;
	private String description;
	private double price;
	private int stock;
	private LocalDateTime expiryDate;
	@ManyToOne
	private Category category;

}
