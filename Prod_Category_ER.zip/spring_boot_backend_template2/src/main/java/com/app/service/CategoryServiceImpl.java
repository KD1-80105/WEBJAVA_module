package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CategoryDao;
import com.app.dto.CategoryDTO;
import com.app.pojos.Category;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao categoryDao;

	@Autowired
	private ModelMapper mapper;

	@Override
	public CategoryDTO addNewCategory(CategoryDTO cat) {
//		DTO --> ENTITY
		Category catEntity = categoryDao.save(mapper.map(cat, Category.class));
//		ENTITY --> DTO
		return mapper.map(catEntity, CategoryDTO.class);
	}

}
