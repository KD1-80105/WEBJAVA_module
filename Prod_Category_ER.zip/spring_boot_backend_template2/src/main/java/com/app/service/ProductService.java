package com.app.service;



import java.util.List;

import com.app.dto.AddProdDTO;
import com.app.dto.ProductDTO;
import com.app.dto.UpdateDTO;
import com.app.pojos.Category;
import com.app.pojos.Product;

public interface ProductService {

	ProductDTO addNewProductInCategory(AddProdDTO dto);

	List<ProductDTO> getByCategory(Long categoryId);

	String deleteById(Long prodId);
	
	public UpdateDTO updateProductDetails(Long prod,UpdateDTO udto);
}
