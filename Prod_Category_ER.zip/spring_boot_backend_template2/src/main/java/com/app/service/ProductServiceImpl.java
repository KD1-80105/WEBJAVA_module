package com.app.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CategoryDao;
import com.app.dao.ProductDao;
import com.app.dto.AddProdDTO;
import com.app.dto.ProductDTO;
import com.app.dto.UpdateDTO;
import com.app.pojos.Category;
import com.app.pojos.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CategoryDao categoryDao;

	public ProductDTO addNewProductInCategory(AddProdDTO newProd) {

//		 find the category id by finder method
		Category category = categoryDao.findById(newProd.getCatId())
				.orElseThrow(() -> new BadInsertion("Cannot find the ID !!!"));
		/*
		 * when the product is found by corresponding id
		 * then that transient product object is mapped with 
		 * entity properties (un-marshalling)
		 */
		Product product = mapper.map(newProd, Product.class);
//		set the transient object from the setter and make it persistent
		product.setCategory(category);
		// then just save the the persistent object into productDAO
		Product persistentProd = productDao.save(product);

		//and again map the persistent object with product DTO class
		return mapper.map(persistentProd, ProductDTO.class);
	}

	@Override
	public List<ProductDTO> getByCategory(Long categoryId) {

		Category category = categoryDao.findById(categoryId).orElseThrow();
		return productDao.findByCategory(category).stream().map(prod -> mapper.map(category, ProductDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public String deleteById(Long prodId) {
		if (productDao.existsById(prodId)) {
			productDao.deleteById(prodId);
			return "product deleted";
		}
		throw new BadInsertion("deletion failed!!");
	}

	@Override
	public UpdateDTO updateProductDetails(Long prod, UpdateDTO udto) {

		Product p = productDao.findById(prod).orElseThrow();
		p.setPrice(udto.getPrice());

		return mapper.map(p, UpdateDTO.class);
	}

}
